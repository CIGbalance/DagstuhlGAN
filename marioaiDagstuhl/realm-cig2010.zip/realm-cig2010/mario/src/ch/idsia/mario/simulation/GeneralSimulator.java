package ch.idsia.mario.simulation;

import ch.idsia.tools.EvaluationInfo;

/**
 * Created by IntelliJ IDEA.
 * User: Sergey Karakovskiy, sergey at idsia dot ch
 * Date: Feb 23, 2010
 * Time: 7:39:49 PM
 * Package: ch.idsia.mario.simulation
 */
public class GeneralSimulator implements Simulation
{
    public void setSimulationOptions(SimulationOptions simulationOptions)
    {
        
    }

    public EvaluationInfo simulateOneLevel()
    {
        return null; 
    }
}
