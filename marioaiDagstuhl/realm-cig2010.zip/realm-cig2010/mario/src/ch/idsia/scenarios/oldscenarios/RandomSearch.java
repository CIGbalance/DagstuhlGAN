package ch.idsia.scenarios.oldscenarios;

/**
 * Created by IntelliJ IDEA.
 * User: julian
 * Date: May 26, 2009
 * Time: 12:33:58 PM
 */
public class RandomSearch {
    // todo

}
