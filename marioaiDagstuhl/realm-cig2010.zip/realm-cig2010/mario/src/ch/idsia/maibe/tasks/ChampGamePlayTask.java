package ch.idsia.maibe.tasks;

import ch.idsia.ai.agents.Agent;
import ch.idsia.mario.environments.Environment;

/**
 * Created by IntelliJ IDEA. \n User: Sergey Karakovskiy, sergey at idsia dot ch Date: Mar 24, 2010 Time: 12:58:00 PM
 * Package: ch.idsia.maibe.tasks
 */
public class ChampGamePlayTask extends BasicTask
{
    public ChampGamePlayTask(Environment environment, Agent agent)
    {
        super(null);
    }

    
}
