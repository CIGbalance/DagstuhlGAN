rm -rf marioai
mkdir marioai
mkdir marioai/src
cp README.entry marioai/README.entry
cp -R src/com marioai/src/
zip -r marioai_a1k0n.zip marioai

